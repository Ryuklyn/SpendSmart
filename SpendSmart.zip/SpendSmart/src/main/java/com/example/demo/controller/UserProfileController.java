package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.ProfilePicture;
import com.example.demo.model.User;
import com.example.demo.model.UserProfile;
import com.example.demo.repository.ImageRepository;
import com.example.demo.repository.ToDoListRepository;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.repository.UserProfileRepository;
import com.example.demo.repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserProfileController {
	
	@Autowired
	private ToDoListRepository tdRepo;
	
	@Autowired
	private TransactionRepository tRepo;

	@Autowired
	UserRepository uRepo;
	
	@Autowired
	UserProfileRepository upRepo;
	
	@Autowired
	ImageRepository imgRepo;
	
	
	@GetMapping("/userprofile")
	public String getUserprofile(@ModelAttribute User u, Model m, HttpServletRequest req) {
	    System.out.println("get profile");
	    Long ntask = tdRepo.count();
	    m.addAttribute("tTask", ntask);
	    
	    Double tIncome = tRepo.getTotalIncome();
	    Double tExpense = tRepo.getTotalExpense();
	    
	    String forIncome = String.format("%.0f", tIncome);
	    String forExpense = String.format("%.0f", tExpense);
	    
	    m.addAttribute("tIncome", forIncome);
	    m.addAttribute("tExpense", forExpense);
	    
	    HttpSession session = req.getSession();
	    User userloggedin = (User) session.getAttribute("loggedinuser");

	    if (userloggedin != null) {
	        System.out.println("User name: " + userloggedin.getName());

	        // Fetch all user profiles and manually find the profile of the logged-in user
	        List<UserProfile> allProfiles = upRepo.findAll();
			/* UserProfile allProfiles = upRepo.findById(null) */
	        UserProfile userProfile = null;

	        for (UserProfile up : allProfiles) {
	            if (up.getId() == userloggedin.getId()) {
	                userProfile = up;
	                System.out.println(up);
	                break;
	            }
	        }

	        if (userProfile != null) {
	            m.addAttribute("upData", userProfile);
	        } else {
	            m.addAttribute("upData", null); // Handle case where no profile exists
	        }

	        session.setAttribute("userData", userloggedin);
	        session.setAttribute("user", userloggedin.getName());
	        m.addAttribute("userData", userloggedin);

	        // Fetch all profile pictures and manually find the picture for the logged-in user
	        List<ProfilePicture> allPictures = imgRepo.findAll();
	        ProfilePicture profilePicture = null;

	        for (ProfilePicture pp : allPictures) {
	            if (pp.getId() == userloggedin.getId()) {
	                profilePicture = pp;
	                break;
	            }
	        }

	        if (profilePicture != null) {
	            m.addAttribute("profileImage", profilePicture);
	        } else {
	            m.addAttribute("profileImage", null); // Handle case where no picture exists
	        }
	    } else {
	        return "redirect:/userprofile"; // Redirect to login page if no user is logged in
	    }

	    return "userprofile";
	}

	
	@PostMapping("/userInfo")
	public String postUserProfile(@ModelAttribute UserProfile up, Model m, HttpServletRequest req) {
	    upRepo.save(up);
	    System.out.println("Post profile");

	    // Optionally update the session or model with the updated user profile
	    HttpSession session = req.getSession();
	    session.setAttribute("userProfile", up);

	    // Add success message to the model
	    m.addAttribute("message", "Profile updated successfully!");

	    return "redirect:/userprofile"; // Redirect to prevent form resubmission
	}

	
}
