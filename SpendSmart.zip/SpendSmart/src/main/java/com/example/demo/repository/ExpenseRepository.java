package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.ExpenseCategory;


public interface ExpenseRepository extends JpaRepository<ExpenseCategory, Integer> {

}
