
package com.example.demo.controller;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.thymeleaf.context.Context;

import com.example.demo.model.Transaction;
import com.example.demo.model.User;
import com.example.demo.repository.ToDoListRepository;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.service.DocumentGenerator;

import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class MailController {

    @Autowired
    private JavaMailSender jms;

    @Autowired
    private DocumentGenerator docGen;
    
    @Autowired 
    private TransactionRepository tRepo;
    
    @Autowired
    private ToDoListRepository tdRepo;
    
    
    
    
    

    @PostMapping("/mail")
    public String postMail(@ModelAttribute User u, HttpServletRequest req, HttpServletResponse res, Model m) {
        try {
        	 HttpSession session = req.getSession();
             User userLoggedIn = (User) session.getAttribute("loggedinuser");

             String to = userLoggedIn.getEmail();  // Get the logged-in user's email
             String subject = "Invoice PDF";
             String message = "Please find the attached invoice.";
        	
            // Generate the PDF
            Context context = new Context();
            context.setVariable("userData", userLoggedIn);
            context.setVariable("transData", tRepo.findAll());
            docGen.generatePdf("forpdf", context);

            // Check if the PDF file is generated successfully
            File generatedFile = new File("newinvoice.pdf");
            if (generatedFile.exists()) {
                System.out.println("PDF successfully generated!");
            } else {
                System.out.println("PDF generation failed.");
                return "Error Generating PDF";
            }

            // Proceed to sending the email (as tested in your /testMail method)
            MimeMessage mimeMessage = jms.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(message);

            // Attach the generated PDF
            FileSystemResource file = new FileSystemResource(generatedFile);
            helper.addAttachment("invoice.pdf", file);
            

           
            jms.send(mimeMessage);
            m.addAttribute("mailSent", "Receipt has been successfully sent to your mail");
            session.setAttribute("mailNotify", "Recent receipt has been successfully sent to your mail. Don't forget to check.");
            
            List<Transaction> tList = tRepo.findAll();
            Double totalIncome = tRepo.getTotalIncome();
            Double totalExpense = tRepo.getTotalExpense();
            Long ntask = tdRepo.count();
            
            
    	    int totalBalance= (int) (totalIncome-totalExpense);

    		m.addAttribute("totBalance", totalBalance);

    		System.out.println("Balance" +totalBalance);
    		// Format the Double to remove .0 if there are no decimal values
    		String formattedIncome = String.format("%.0f", totalIncome);
    		String formattedExpense = String.format("%.0f", totalExpense);

    		m.addAttribute("totalIncome", formattedIncome);
    		m.addAttribute("totalExpense", formattedExpense);
            
            m.addAttribute("allData", tList);
            
            m.addAttribute("totalTask", ntask);
            return "dashboard";

        } catch (Exception e) {
            e.printStackTrace();
            m.addAttribute("mailError", "Mail sent has been unexpectedly canceled.");
            return "dashboard";
        }
    }

}













