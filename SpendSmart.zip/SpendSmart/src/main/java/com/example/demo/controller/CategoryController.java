package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.ExpenseCategory;
import com.example.demo.model.IncomeCategory;
import com.example.demo.repository.ExpenseRepository;
import com.example.demo.repository.IncomeRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class CategoryController {

	
	 @Autowired
	    private IncomeRepository inRepo;

	 @Autowired
	    private ExpenseRepository exRepo;
	    
	    @GetMapping("/category")
	    public String showCategories(Model model) {
	    	
	    	System.out.println("Inex 3");
	        // Initialize new objects for the form
	        model.addAttribute("newIncomeCategory", new IncomeCategory());
	        model.addAttribute("newExpenseCategory", new ExpenseCategory());

	        // Fetch categories to display
	        List<IncomeCategory> incomeCategories = inRepo.findAll();
	        List<ExpenseCategory> expenseCategories = exRepo.findAll();

	        model.addAttribute("incomeCategories", incomeCategories);
	        model.addAttribute("expenseCategories", expenseCategories);

	        return "category";
	    }
	    @PostMapping("/addIncomeCategory")
	    public String addIncomeCategory(@ModelAttribute("newIncomeCategory") IncomeCategory incomeCategory) {
	        inRepo.save(incomeCategory);
	        return "redirect:/category"; // Redirect back to categories page after adding
	    }

	    @PostMapping("/addExpenseCategory")
	    public String addExpenseCategory(@ModelAttribute("newExpenseCategory") ExpenseCategory expenseCategory) {
	        exRepo.save(expenseCategory);
	        return "redirect:/category"; // Redirect back to categories page after adding
	    }
	    
	    
	    @PostMapping("/deleteIncomeCategory/{id}")
	    public String deleteIncomeCategory(@PathVariable("id") int id) {
	        inRepo.deleteById(id);  // Delete the category from the repository using its ID
	        return "redirect:/categ	ory"; // Redirect to the categories page after deletion
	    }
	    
	    @PostMapping("/deleteExpenseCategory/{id}")
	    public String deleteExpenseCategory(@PathVariable("id") int id) {
	        exRepo.deleteById(id);  // Delete the category from the repository using its ID
	        return "redirect:/category"; // Redirect to the categories page after deletion
	    }
	    
	    @PostMapping("/updateIncomeCategory")
	    public String updateIncomeCategory(@RequestParam("id") int id, @RequestParam("incategory") String incategory, HttpServletRequest req) {
	        IncomeCategory category = inRepo.findById(id).orElse(null);
	        HttpSession session = req.getSession();
	        
	        
	        System.out.println("Entering postEditTask with ID: " + id);
	        if (category != null) {
	        	String oldIncat = category.getIncategory();
	            category.setIncategory(incategory);
	            
	           
	            inRepo.save(category);
	            session.setAttribute("incatNotify", "Category '" + oldIncat + "' was replaced with '" + incategory + "'.");
	        }
	        return "redirect:/category";
	    }
	    
	    
	    @PostMapping("/updateExpenseCategory")
	    public String updateExpenseCategory(@RequestParam("id") int id, @RequestParam("excategory") String excategory, HttpServletRequest req) {
	    	 System.out.println("Entering postEditTask with ID: " + id);
	       ExpenseCategory category = exRepo.findById(id).orElse(null);
	       System.out.println("Excat Edit 1");
	       HttpSession session = req.getSession();
	        if (category != null) {
	        	System.out.println("Excat Edit 2");
	        	String oldExcat = category.getExcategory();
	        	
	        	category.setExcategory(excategory);
	        	exRepo.save(category);
	        	 session.setAttribute("excatNotify", "Category '" + oldExcat + "' was replaced with '" + excategory + "'.");
	        }
	        return "redirect:/category";
	    }

	    
	    @PostMapping("/category")
	    public String processCategoryForm(@ModelAttribute("newIncomeCategory") IncomeCategory newIncomeCategory, Model model) {

	        return "redirect:/category";
	    }

	    
	    @GetMapping("/category/{id}")
	    @ResponseBody
	    public IncomeCategory getCategoryById(@PathVariable int id) {
	    	System.out.println("id category");
	        return inRepo.findById(id).orElse(null); 
	    }
	    
	    
	    @GetMapping("/excategory/{id}")
	    @ResponseBody
	    public ExpenseCategory getExCategoryById(@PathVariable int id) {
	    	System.out.println("id category expense");
	        return exRepo.findById(id).orElse(null); 
	    }

}
