package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class IncomeCategory {

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private int id;
	private String incategory;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIncategory() {
		return incategory;
	}
	public void setIncategory(String incategory) {
		this.incategory = incategory;
	}
	public IncomeCategory(String incategory) {
		super();
		this.incategory = incategory;
	}
	public IncomeCategory() {
		super();
	}
	
	
	
	
}
