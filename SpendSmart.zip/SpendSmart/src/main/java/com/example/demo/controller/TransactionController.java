package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Expense;
import com.example.demo.model.ExpenseCategory;
import com.example.demo.model.Income;
import com.example.demo.model.IncomeCategory;
import com.example.demo.model.Transaction;
import com.example.demo.model.User;
import com.example.demo.repository.ExpenseRepository;
import com.example.demo.repository.IncomeRepository;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
public class TransactionController {

	@Autowired
	private IncomeRepository iRepo;
	
	@Autowired
	private ExpenseRepository eRepo;

	/*
	 * @Autowired private UserRepository uRepo;
	 */
	
	@Autowired
	private TransactionRepository tRepo;
	

	@GetMapping("income")
	public String getIncome(Model m) {
		
		List<IncomeCategory> incatList = iRepo.findAll();
		m.addAttribute("inCat", incatList);
		System.out.println("cat"+incatList);
		return "income";
	}
	
	@GetMapping("expense")
	public String getExpense(Model m) {
		
		List<ExpenseCategory> excatList = eRepo.findAll();
		m.addAttribute("exCat", excatList);
		return "expense";
	}
	
	@GetMapping("transaction")
	public String getTransaction() {
		return "redirect:transaction";
	}
	
	@PostMapping("transaction")
	public String postTransaction(@ModelAttribute Transaction t, Model m, @RequestParam ("transactionType") String transactionType) {
		t.setTransactionType(transactionType);
		tRepo.save(t);
		
		System.out.println("Tryuk");
		List<Transaction> tList = tRepo.findAll();

		
		m.addAttribute("transactionType", transactionType);
		m.addAttribute("allData", tList);
		
		return "dashboard";
	}
	
	@GetMapping("/edit/{id}")
	public String editTransaction(@PathVariable("id") int id, Model model) {
	    Transaction transaction = tRepo.findById(id).orElseThrow(() -> 
	        new IllegalArgumentException("Invalid transaction id:" + id));
	    
	    model.addAttribute("transaction", transaction);
	    
	    if ("income".equals(transaction.getTransactionType())) {
	    	model.addAttribute("inSuccess", "New income transaction has been successfully added!");
	    	List<IncomeCategory> incatList = iRepo.findAll();
			model.addAttribute("inCat", incatList);
	        return "editincome";
	    } else if ("expense".equals(transaction.getTransactionType())) {
	    	model.addAttribute("exSuccess", "New expense transaction has been successfully added!");
	    	List<ExpenseCategory> excatList = eRepo.findAll();
			model.addAttribute("exCat", excatList);
	        return "editexpense"; 
	    } else {
	        throw new IllegalArgumentException("Invalid transaction type: " + transaction.getTransactionType());
	    }
	}
	
	@PostMapping("/edit")
	public String updateTransaction(@ModelAttribute("transaction") Transaction transaction, RedirectAttributes redirectAttributes) {
		// Check if transaction ID is valid (greater than 0)
		if (transaction.getId() <= 0) {
		    redirectAttributes.addFlashAttribute("errorMessage", "Invalid transaction ID.");
		    return "redirect:/dashboard"; // Redirect to the transactions page or error page
		}


	    // Retrieve the transaction by ID from the repository
	    Transaction existingTransaction = tRepo.findById(transaction.getId())
	        .orElseThrow(() -> new IllegalArgumentException("Invalid transaction id: " + transaction.getId()));

	    // Update the existing transaction with the new values from the form
	    existingTransaction.setCategory(transaction.getCategory());
	    existingTransaction.setAmount(transaction.getAmount());
	    existingTransaction.setPaymethod(transaction.getPaymethod());
	    existingTransaction.setNote(transaction.getNote());
	    existingTransaction.setDate(transaction.getDate());
	    existingTransaction.setTime(transaction.getTime());

	    // Save the updated transaction back to the database
	    tRepo.save(existingTransaction);

	    // Add a success message to display after redirection
	    redirectAttributes.addFlashAttribute("successMessage", "Transaction updated successfully!");

	    // Redirect to a specific view or page (e.g., transaction listing or dashboard)
	    return "redirect:/dashboard";
	}

	
	@GetMapping("/delete/{id}")
	public String deleteTransaction(@PathVariable("id") int id, RedirectAttributes redirectAttributes) {
	    tRepo.deleteById(id);
	    
	    redirectAttributes.addFlashAttribute("message", "Transaction deleted successfully");

	    return "redirect:/dashboard"; // Redirect to the dashboard after deletion
	}

}
