package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.ToDoList;

public interface ToDoListRepository extends JpaRepository<ToDoList, Integer>{

}
