package com.example.demo.service;

import java.io.FileOutputStream;
import java.io.OutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.itextpdf.html2pdf.HtmlConverter;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class DocumentGenerator {
	@Autowired
	private ResourceLoader resourceLoader;
	
	@Autowired
	private ServletContext servletContext;
	
	@Autowired
	private SpringTemplateEngine templateEngine;
	
	
	public void generatePdf(String templateName, Context context) throws Exception {
        String html = templateEngine.process(templateName, context);
        
        ITextRenderer renderer = new ITextRenderer();
      renderer.setDocumentFromString(html);
      renderer.layout();

      String outputPdfPath= "newinvoice.pdf";
      try (OutputStream os = new FileOutputStream(outputPdfPath)) {
          renderer.createPDF(os);
         
      
      }	
        
    }
	
}
