package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Transaction;
import com.example.demo.model.User;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


@Controller
public class ReceiptController {
	
	@Autowired
	TransactionRepository tRepo;
	
	@Autowired
	UserRepository uRepo;
	

	@GetMapping("/receipt")
	public String getReceipt(@ModelAttribute User u ,Model m , HttpServletRequest req) {
		
		
		HttpSession session = req.getSession();
		User userloggedin = (User) session.getAttribute("loggedinuser");
		
		
		List< Transaction > tList = tRepo.findAll();
		/* List<User> uList = uRepo.findAll(); */
		m.addAttribute("transData", tList);
		m.addAttribute("userData", userloggedin);
		return "receipt";
	}
	
	
}
