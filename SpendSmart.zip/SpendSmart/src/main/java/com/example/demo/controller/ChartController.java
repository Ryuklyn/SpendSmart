package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.model.Transaction;
import com.example.demo.repository.TransactionRepository;

@Controller
public class ChartController {
	
	@Autowired
	private TransactionRepository tRepo;
	
	/*
	 * @GetMapping("/chart") public String getChart() { return "chart"; }
	 */
	@GetMapping("/chart")
	public String getChart(Model model) {
	    System.out.println("Entering Chart get");

	    // Fetch all transactions
	    List<Transaction> transactions = tRepo.findAll();

	    // Separate income and expense data
	    List<String> labels = new ArrayList<>();
	    List<Integer> incomeData = new ArrayList<>();
	    List<Integer> expenseData = new ArrayList<>();

	    // For pie chart
	    Map<String, Integer> incomeCategoryMap = new HashMap<>();
	    Map<String, Integer> expenseCategoryMap = new HashMap<>();

	    for (Transaction t : transactions) {
	        labels.add(t.getDate().toString());

	        if (t.getTransactionType().equals("income")) {
	            incomeData.add(t.getAmount());
	            expenseData.add(0); // No expense for this date
	            
	            // Add to income category map
	            incomeCategoryMap.put(t.getCategory(),
	                incomeCategoryMap.getOrDefault(t.getCategory(), 0) + t.getAmount());
	        } else {
	            expenseData.add(t.getAmount());
	            incomeData.add(0); // No income for this date

	            // Add to expense category map
	            expenseCategoryMap.put(t.getCategory(),
	                expenseCategoryMap.getOrDefault(t.getCategory(), 0) + t.getAmount());
	        }
	    }

	    // Prepare data for the pie charts
	    List<String> incomeCategories = new ArrayList<>(incomeCategoryMap.keySet());
	    List<Integer> incomeCategoryData = new ArrayList<>(incomeCategoryMap.values());
	    
	    List<String> expenseCategories = new ArrayList<>(expenseCategoryMap.keySet());
	    List<Integer> expenseCategoryData = new ArrayList<>(expenseCategoryMap.values());

	    // Pass data to the view
	    model.addAttribute("labels", labels);
	    model.addAttribute("inData", incomeData);
	    model.addAttribute("exData", expenseData);

	    // Pie chart data
	    model.addAttribute("incomeCategories", incomeCategories);
	    model.addAttribute("incomeCategoryData", incomeCategoryData);
	    
	    model.addAttribute("expenseCategories", expenseCategories);
	    model.addAttribute("expenseCategoryData", expenseCategoryData);

	    return "/chart"; // Ensure this matches your Thymeleaf template name
	}


}
