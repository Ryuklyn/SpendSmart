package com.example.demo.controller;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.example.demo.model.IncomeCategory;
import com.example.demo.model.ToDoList;
import com.example.demo.repository.ToDoListRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ToDoListController {

	@Autowired
	private ToDoListRepository tdRepo;
	
	@GetMapping("/todolist")
	public String getToDoList(Model m, HttpServletRequest req) {
	    System.out.println("Entering getToDoList method");
	    
	    m.addAttribute("newToDoList", new ToDoList());
	    
	    List<ToDoList> todoList = tdRepo.findAll();
	    
	    HttpSession session = req.getSession();
	    
	    if (todoList.isEmpty()) {
	        System.out.println("No tasks found in ToDoList");
	    } else {
	        System.out.println("Processing and sorting tasks...");
	        
	        // Process and calculate reminders
	        todoList.forEach(task -> {
	            System.out.println("Processing task: " + task.getTask());
	            Date timestamp = task.getTimestamp();
	            
	            if (timestamp != null) {
	                LocalDateTime taskTime = timestamp.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	                LocalDateTime now = LocalDateTime.now();
	                
	                // Calculate the difference
	                long daysDiff = ChronoUnit.DAYS.between(now.toLocalDate(), taskTime.toLocalDate());
	                long hoursDiff = ChronoUnit.HOURS.between(now, taskTime);
	                long minutesDiff = ChronoUnit.MINUTES.between(now, taskTime);
	                
	                if (daysDiff == 0) {
	                    long remainingHours = hoursDiff % 24;
	                    long remainingMinutes = minutesDiff % 60;
	                    
	                    if (hoursDiff < 0 || minutesDiff < 0) {
	                        task.setReminder("Task time has passed");
	                    } else {
	                        task.setReminder(remainingHours + " hrs " + remainingMinutes + " mins");
	                        
	                        // If less than 24 hours, set taskNotify in session
	                        if (hoursDiff <= 24) {
	                            session.setAttribute("taskNotify", task.getTask() + ", less than 24 hours for this task");
	                        }
	                    }
	                } else if (daysDiff < 0) {
	                    task.setReminder("Task time has passed");
	                } else {
	                    task.setReminder(daysDiff + " days");
	                }
	            } else {
	                task.setReminder("No timestamp available");
	            }
	        });
	        
	        // Sort tasks by timestamp (the shortest time first)
	        todoList.sort((task1, task2) -> {
	            Date timestamp1 = task1.getTimestamp();
	            Date timestamp2 = task2.getTimestamp();
	            
	            if (timestamp1 == null && timestamp2 == null) {
	                return 0;
	            } else if (timestamp1 == null) {
	                return 1; // Task with no timestamp goes to the end
	            } else if (timestamp2 == null) {
	                return -1; // Task with no timestamp goes to the end
	            } else {
	                return timestamp1.compareTo(timestamp2); // Sort by the closest time
	            }
	        });
	    }
	    
	    m.addAttribute("todoList", todoList);
	    return "todolist";
	}


	
	
	

	@PostMapping("/addToDoList")
	public String postToDoList(@ModelAttribute("newToDoList") ToDoList todoList, Model m,
			RedirectAttributes redirectAttributes) {
		// Ensure timestamp is populated
		if (todoList.getTimestamp() == null) {
			todoList.setTimestamp(new Date()); // Set current time if no timestamp is provided
		}

		tdRepo.save(todoList);
		List<ToDoList> tdList = tdRepo.findAll();
		m.addAttribute("tdlistData", tdList);
		m.addAttribute("tasklist", "New Task has been successfully added!");
		redirectAttributes.addFlashAttribute("tasklist", "New Task has been successfully added!");
		return "redirect:/todolist";
	}

	@GetMapping("/deletelist/{id}")
	public String deleteTransaction(@PathVariable("id") int id, RedirectAttributes redirectAttributes) {
		tdRepo.deleteById(id);

		redirectAttributes.addFlashAttribute("message", "Transaction deleted successfully");

		return "redirect:/todolist"; // Redirect to the dashboard after deletion
	}

	@GetMapping("/editlist/{id}")
	public String editLists(@PathVariable("id") int id, Model m) {
		return "todolist";
	}

	@GetMapping("/edittask/{id}")
	@ResponseBody
	public ToDoList getCategoryById(@PathVariable int id) {
		System.out.println("id task");
		return tdRepo.findById(id).orElse(null);
	}

	
	@PostMapping("/updateTask")
	public String postEditTask(@RequestParam ("id") int id, @RequestParam("task") String task, 
	                           @RequestParam ("date") String date, @RequestParam ("time") String time, 
	                           RedirectAttributes redirectAttributes) {
	    
	    System.out.println("Entering postTodoList");
	    System.out.println("Entering postEditTask with ID: " + id);
	    
	    ToDoList tdTask = tdRepo.findById(id).orElse(null);
	    
	    if (tdTask != null) {
	        tdTask.setTask(task);
	        tdTask.setDate(date);
	        tdTask.setTime(time);
	        
	        // Convert date and time to a timestamp
	        LocalDateTime dateTime = LocalDateTime.parse(date + "T" + time);
	        tdTask.setTimestamp(Timestamp.valueOf(dateTime));
	        
	        System.out.println("Updated Task: " + tdTask.getTask());
	        
	        tdRepo.save(tdTask);
	    }
	    
	    return "redirect:/todolist";
	}

	

}
