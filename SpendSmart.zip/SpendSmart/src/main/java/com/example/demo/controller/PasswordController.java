
package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.OtpService;


@Controller
public class PasswordController {

	
	@Autowired
	private UserRepository uRepo;
	
    @Autowired
    private JavaMailSender jms;

    @Autowired
    private OtpService otpService;  // Injecting OtpService to generate OTP

    @GetMapping("/forgetpwrd")
    public String getPwrd() {

        return "forgetpwrd";  // Return the forget password page
    }
    
    @GetMapping ("/changepwrd")
    public String getChange() {
    	
    	return "changepwrd";
    }
    
    @PostMapping("/resetpwrd")
    public String postPwrd(@RequestParam("email") String email, Model m, HttpServletRequest req) {
        // Check if the email exists in the UserRepository
        if (uRepo.findByEmail(email) != null) {
        	
        	HttpSession sson = req.getSession();
        	
            // Generate OTP
            String otp = otpService.generateOtp();
            
            sson.setAttribute("sentOtp", otp);
            sson.setAttribute("sentEmail", email);

            // Prepare email details
            String to = email;
            String subject = "Password Reset OTP";
            String message = "Your OTP for password reset is: " + otp;

            // Send OTP via email
            try {
                MimeMessage mimeMessage = jms.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
                helper.setTo(to);
                helper.setSubject(subject);
                helper.setText(message);

                jms.send(mimeMessage); // Send the email

                m.addAttribute("mailSent", "OTP has been successfully sent to your email.");
            } catch (MessagingException e) {
                e.printStackTrace();
                m.addAttribute("mailError", "Failed to send OTP email. Please try again.");
                return "otp"; // Stay on the OTP page if email sending fails
            }

            return "otp"; // Proceed to the OTP page
        } else {
            // Email is not registered
            m.addAttribute("noEmail", "Email isn't registered!");
            return "login"; // Show the same page with the error
        }
    }
    
    @PostMapping("/otp")
    public String postOtp(@RequestParam ("otp") String otp, HttpServletRequest req, Model m) {
    	
    	HttpSession seson = req.getSession();
    	
    	String sentOtp = (String) seson.getAttribute("sentOtp");
    	
    	if (sentOtp != null && sentOtp.equals(otp)) {
			return "changepwrd";
		} else {
	        // OTP is invalid, stay on the OTP page and show an error message
	        m.addAttribute("noOtp", "Entered OTP is incorrect. Please try again.");
	        return "otp"; // Stay on the OTP page
	    }
        
       
    }
    @PostMapping("/newpassword")
    public String postNewPassword(@RequestParam("newPassword") String newPwrd, HttpServletRequest req, Model m) {
        // Get session and retrieve the sentEmail attribute
        HttpSession session = req.getSession();
        String sentEmail = (String) session.getAttribute("sentEmail");

        // Find the user by email from the repository
        User user = uRepo.findByEmail(sentEmail);

        // Check if the user exists
        if (user != null) {
            // Update the user's password
            user.setPassword(newPwrd);
            uRepo.save(user); // Save the updated user back to the database

            // Add success message to the model (optional)
            session.setAttribute("notifyChange", "Password successfully updated. Please login with your new password.");
            m.addAttribute("changeMessage", "Password successfully updated.");

            // Redirect to the login page
            return "login";
        } else {
            // If user is not found, add error message
            m.addAttribute("error", "Password Change Interrupted");
            return "login"; // Redirect back to the change password page if there's an error
        }
    }

    
    
    
}