package com.example.demo.service;

import org.springframework.stereotype.Service;
import java.security.SecureRandom;

@Service
public class OtpService {

    private static final int OTP_LENGTH = 6;
    private SecureRandom random = new SecureRandom();

    // Method to generate 6 digit OTP
    public String generateOtp() {
        int otp = random.nextInt(900000) + 100000; // Generate a number between 100000 and 999999
        return String.valueOf(otp);
    }

    // Method to validate the OTP
    public boolean validateOtp(String inputOtp, String actualOtp) {
        return inputOtp.equals(actualOtp);
    }
}
