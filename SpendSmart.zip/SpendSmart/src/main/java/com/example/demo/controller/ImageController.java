package com.example.demo.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.ProfilePicture;
import com.example.demo.model.User;
import com.example.demo.repository.ImageRepository;
import com.example.demo.repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class ImageController {

	@Autowired
	private ImageRepository imgRepo;
	
	@Autowired
	private UserRepository uRepo;
	
	@PostMapping("/upload")
	public String postUpload(@RequestParam("file") MultipartFile file, HttpServletRequest req) {
	    byte[] imgByte;
	    try {
	        imgByte = file.getBytes();
	        String imgString = Base64.getEncoder().encodeToString(imgByte);
	        List<ProfilePicture> profilePictures = imgRepo.findAll();
	        ProfilePicture img;
	        
	        if (!profilePictures.isEmpty()) {
	            img = profilePictures.get(0); // Get the first profile picture
	            img.setImg(imgString); // Update the existing image
	        } else {
	            img = new ProfilePicture(); // Create a new one if none exists
	            img.setImg(imgString);
	        }
	        
	        HttpSession session = req.getSession();
	        User loggedinUser = (User) session.getAttribute("loggedinuser");
	        
	        User u2 = new User();
	        
	        
	        
	        imgRepo.save(img); // Save the updated or new image
	        session.setAttribute("imageNotify", "Profile picture has been changed, New picture is active from now on.");
	        
	        
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return "redirect:/userprofile";
	}


	
	
}
