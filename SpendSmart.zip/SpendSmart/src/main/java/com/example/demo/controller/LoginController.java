package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class LoginController {
	
	@Autowired
	private UserRepository uRepo;
	
	@GetMapping("/login")
	public String getLogin() {
		return "login";
	}
	
	/*
	 * @GetMapping("/forgetpwrd") public String getPwrd() { return "forgetpwrd"; }
	 */
	
	
	@PostMapping("/login")
	public String postMethodName(@ModelAttribute User u, Model m, HttpServletRequest req) {
		System.out.println(u.getEmail());
		System.out.println(u.getPassword());
		
		HttpSession session = req.getSession();
		
		if (uRepo.existsByEmailAndPassword(u.getEmail(), u.getPassword())) {
			
			// Retrieve the full user object from the database
	        User loggedInUser = uRepo.findByEmailAndPassword(u.getEmail(), u.getPassword());
	        System.out.println("User name: " + loggedInUser.getName());
			List<User> uList = uRepo.findAll();
			m.addAttribute("allData", uList);
			session.setAttribute("loggedinuser", loggedInUser);
			session.setAttribute("user", loggedInUser.getName());
			/* m.addAttribute("user", loggedInUser); */
			return "redirect:dashboard";
		}else {
			m.addAttribute("failed", "Invalid Username and Password");
			return "login";
		}
	}
	
	
	@GetMapping("/logout")
	public String getLogout(HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.invalidate();
		return "login";
	}
	

}
