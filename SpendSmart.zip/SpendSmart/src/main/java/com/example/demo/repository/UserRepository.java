package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Income;
import com.example.demo.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	boolean existsByEmailAndPassword(String email, String password);
	 User findByEmailAndPassword(String email, String password);
	 User findByEmail(String email);
	
}
