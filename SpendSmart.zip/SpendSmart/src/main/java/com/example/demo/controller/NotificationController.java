package com.example.demo.controller;

/*import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class NotificationController {
	
	@GetMapping("/notification")
	public String getNotification(HttpServletRequest req) {
		HttpSession session = req.getSession();
		
		session.setAttribute("versionNotify", "A latest version is available, download from spendsmart official website.");
		String resetPassword = (String) session.getAttribute("notifyChange");
		String mailNotify = (String) session.getAttribute("mailNotify");
		String imageNotify = (String) session.getAttribute("imageNotify");
		String incatNotify = (String) session.getAttribute("incatNotify");
		String excatNotify = (String) session.getAttribute("excatNotify");
		
		session.setAttribute("resetNotify", resetPassword);
		session.setAttribute("mailNotify", mailNotify);
		session.setAttribute("imageNotify", imageNotify);
		session.setAttribute("incatNotify", incatNotify);
		session.setAttribute("excatNotify",excatNotify);
		
		 // Print the values for debugging
        System.out.println("versionNotify: " + session.getAttribute("versionNotify"));
        System.out.println("resetNotify: " + session.getAttribute("resetNotify"));
        System.out.println("mailNotify: " + session.getAttribute("mailNotify"));
        System.out.println("imageNotify: " + session.getAttribute("imageNotify"));
        System.out.println("incatNotify: " + session.getAttribute("incatNotify"));
        System.out.println("excatNotify: " + session.getAttribute("excatNotify"));
		
		return "notification";
	}*/

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class NotificationController {

    private static final Logger logger = LoggerFactory.getLogger(NotificationController.class);

    @GetMapping("/notification")
    public String getNotification(HttpServletRequest req, Model model) {
        HttpSession session = req.getSession();

        // Fetch attributes from session
        String versionNotify = (String) session.getAttribute("versionNotify");
        String resetNotify = (String) session.getAttribute("resetNotify");
        String mailNotify = (String) session.getAttribute("mailNotify");
        String imageNotify = (String) session.getAttribute("imageNotify");
        String incatNotify = (String) session.getAttribute("incatNotify");
        String excatNotify = (String) session.getAttribute("excatNotify");
        String taskNotify = (String) session.getAttribute("taskNotify");

        // Log values for debugging
        logger.info("Version Notify: {}", versionNotify);
        logger.info("Reset Notify: {}", resetNotify);
        logger.info("Mail Notify: {}", mailNotify);
        logger.info("Image Notify: {}", imageNotify);
        logger.info("Income Category Notify: {}", incatNotify);
        logger.info("Expense Category Notify: {}", excatNotify);
        logger.info("To Do List Notify: {}", taskNotify);

        // Add attributes to the model
        model.addAttribute("versionNotify", versionNotify);
        model.addAttribute("resetNotify", resetNotify);
        model.addAttribute("mailNotify", mailNotify);
        model.addAttribute("imageNotify", imageNotify);
        model.addAttribute("incatNotify", incatNotify);
        model.addAttribute("excatNotify", excatNotify);
        model.addAttribute("taskNotify", taskNotify);

        return "notification";
    }

	
    @PostMapping("/dismissNotification/{type}")
    public String dismissNotification(HttpServletRequest req, @PathVariable("type") String type) {
        HttpSession session = req.getSession();
        session.removeAttribute(type); // remove the specific notification from the session
        return "redirect:/notification"; // Redirect back to the notification page
    }

    @PostMapping("/dismissAllNotifications")
    public String dismissAllNotifications(HttpServletRequest req) {
        HttpSession session = req.getSession();
        session.removeAttribute("versionNotify");
        session.removeAttribute("resetNotify");
        session.removeAttribute("mailNotify");
        session.removeAttribute("imageNotify");
        session.removeAttribute("incatNotify");
        session.removeAttribute("excatNotify");
        session.removeAttribute("taskNotify");
        return "redirect:/notification"; // Redirect back to the notification page
    }


}
