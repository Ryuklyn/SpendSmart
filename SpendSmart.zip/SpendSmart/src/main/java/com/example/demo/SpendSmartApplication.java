package com.example.demo;

import java.sql.Array;
import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.model.ExpenseCategory;
import com.example.demo.model.IncomeCategory;
import com.example.demo.repository.ExpenseRepository;
import com.example.demo.repository.IncomeRepository;

@SpringBootApplication
public class SpendSmartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpendSmartApplication.class, args);
	}
	
	@Bean
    public CommandLineRunner initDatabase(IncomeRepository incomeRepository, ExpenseRepository expenseRepository) {
        return args -> {
            if (incomeRepository.count() == 0) {  // If there are no categories, insert defaults
                incomeRepository.saveAll(Arrays.asList(
                    new IncomeCategory("Rental"),
                    new IncomeCategory("Salary"),
                    new IncomeCategory("Sale"),
                    new IncomeCategory("Dividends"),
                    new IncomeCategory("Awards"),
                    new IncomeCategory("Coupons")
                ));
            }
            
            if (expenseRepository.count() == 0) {  // If there are no categories, insert defaults
                expenseRepository.saveAll(Arrays.asList(
                	new ExpenseCategory("Education"),
                	new ExpenseCategory("Entertainment"),
                	new ExpenseCategory("Groceries"),
                	new ExpenseCategory("Healthcare"),
                	new ExpenseCategory("Rent"),
                	new ExpenseCategory("Travel")
                		
                ));
            }
            
        };
    }

}
