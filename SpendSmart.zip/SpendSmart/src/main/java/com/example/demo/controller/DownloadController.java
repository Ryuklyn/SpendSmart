package com.example.demo.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.http.HttpHeaders;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.thymeleaf.context.Context;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.User;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.service.DocumentGenerator;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class DownloadController {

	@Autowired
	private DocumentGenerator docGen;
	
	@Autowired
	private TransactionRepository tRepo;
	
	@GetMapping("/download-invoice")
	public String downloadInvoice(HttpServletRequest req, HttpServletResponse res, Model m) {
	    try {
	        // Get the logged-in user details
	        HttpSession session = req.getSession();
	        User userLoggedIn = (User) session.getAttribute("loggedinuser");

	        // Generate the PDF
	        Context context = new Context();
	        context.setVariable("userData", userLoggedIn);
	        context.setVariable("transData", tRepo.findAll());
	        docGen.generatePdf("forpdf", context);

	        // Check if the PDF file is generated successfully
	        File generatedFile = new File("newinvoice.pdf");
	        if (!generatedFile.exists()) {
	            throw new RuntimeException("Invoice generation failed.");
	        }

	        // Set the response headers to download the PDF
	        res.setContentType("application/pdf");
	        res.setHeader("Content-Disposition", "attachment; filename=invoice.pdf");
	        res.setContentLength((int) generatedFile.length());

	        // Stream the PDF file to the response
	        FileInputStream fileInputStream = new FileInputStream(generatedFile);
	        OutputStream responseOutputStream = res.getOutputStream();
	        byte[] buffer = new byte[1024];
	        int bytesRead;
	        while ((bytesRead = fileInputStream.read(buffer)) != -1) {
	            responseOutputStream.write(buffer, 0, bytesRead);
	        }
	        fileInputStream.close();
	        responseOutputStream.flush();

	        m.addAttribute("mailSent", "Receipt has been sucessfully downloaded");
	        // Redirect to the dashboard after download
	        return "dashboard";

	    } catch (IOException e) {
	        e.printStackTrace();
	        m.addAttribute("mailError", "Invoice generation failed.");
	        return "dashboard";  // Display error on dashboard
	    } catch (Exception e) {
	        e.printStackTrace();
	        m.addAttribute("mailError", "Unexpected error occurred.");
	        return "dashboard";
	    }
	}

		
	
}
