package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.repository.UserRepository;


@Controller
public class LandingController {
	@Autowired
	private UserRepository uRepo;

	@GetMapping("/")
	public String getHome() {
		return "index";
	}
	
}
