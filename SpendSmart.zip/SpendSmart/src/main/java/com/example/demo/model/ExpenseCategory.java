package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ExpenseCategory {

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private int id;
	private String excategory;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getExcategory() {
		return excategory;
	}
	public void setExcategory(String excategory) {
		this.excategory = excategory;
	}
	public ExpenseCategory(String excategory) {
		super();
		this.excategory = excategory;
	}
	public ExpenseCategory() {
		super();
	}
	
	
}
