package com.example.oop_project.model;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class NotificationHandler {
    private static List<String> notifications = new ArrayList<>();
    private static List<PrintWriter> clients = new ArrayList<>();

    public static void notifyClients(String notification) {
        notifications.add(notification);

        // Send the new notification to all connected clients
        for (PrintWriter client : clients) {
            client.println(notification);
        }
    }

    public static List<String> getNotifications() {
        return notifications;
    }

    public static void addClient(PrintWriter client) {
        clients.add(client);
    }

    public static void removeClient(PrintWriter client) {
        clients.remove(client);
    }
}
