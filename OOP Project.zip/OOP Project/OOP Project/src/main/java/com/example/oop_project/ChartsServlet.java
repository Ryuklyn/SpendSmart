package com.example.oop_project;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.oop_project.DBConnection.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet(name = "ChartsServlet", value = "/ChartsServlet")  // Correct the servlet mapping
public class ChartsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();
            String query = "SELECT category, SUM(amount) AS total_amount FROM addtransaction GROUP BY category";
            PreparedStatement stmt = conn.prepareStatement(query);

            ResultSet rs = stmt.executeQuery();
            List<Map<String, String>> data = new ArrayList<>();

            while (rs.next()) {
                Map<String, String> item = new HashMap<>();
                item.put("category", rs.getString("category"));
                item.put("total_amount", rs.getString("total_amount"));
                data.add(item);
            }

            // Convert the data to JSON and send it to the client
            Gson gson = new Gson();
            String jsonData = gson.toJson(data);
            out.println(jsonData);

        } catch (SQLException e) {
            e.printStackTrace();
            out.println("Error loading chart data");
        }
    }
}
