
package com.example;

import com.example.oop_project.DBConnection.DBConnection;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.example.oop_project.passwordhashing.HashPassword;

@WebServlet(name = "RegisterServlet", value = "/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection con = DBConnection.getConnection();

        String uname = request.getParameter("userName");
        String plainPassword = request.getParameter("password");

        try {
            String hashedPassword = HashPassword.hash(plainPassword);

            PreparedStatement ps = con.prepareStatement("INSERT INTO registered_users (username, password) VALUES (?, ?)");
            ps.setString(1, uname);
            ps.setString(2, hashedPassword);

            int rows = ps.executeUpdate();
            if (rows != 0) {
                System.out.println("User Added successfully");

                con.close();

                RequestDispatcher dispatcher = request.getRequestDispatcher("pages/login.jsp");
                dispatcher.forward(request, response);
            } else {
                System.out.println("error");
                RequestDispatcher dispatcher = request.getRequestDispatcher("pages/register.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }
}
