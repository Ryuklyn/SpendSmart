package com.example.oop_project;
import com.example.oop_project.DBConnection.DBConnection;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/recentTransactionsServlet")
public class RecentTransactionServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();
            String query = "SELECT * FROM addtransaction ORDER BY transaction_date DESC, transaction_time DESC LIMIT 5";
            PreparedStatement stmt = conn.prepareStatement(query);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String category = rs.getString("category");
                String amount = rs.getString("amount");
                String date = rs.getString("transaction_date");
                String time = rs.getString("transaction_time");
                String notes = rs.getString("notes");

                // Build HTML for each transaction card
                out.println("<div class='card transaction-card'>");
                out.println("<div class='card-body'>");
                out.println("<h5 class='card-title'>Category: " + category + "</h5>");
                out.println("<p class='card-text'>Amount: " + amount + "</p>");
                out.println("<p class='card-text'>Date: " + date + "</p>");
                out.println("<p class='card-text'>Time: " + time + "</p>");
                out.println("<p class='card-text'>Notes: " + notes + "</p>");
                out.println("</div>");
                out.println("</div>");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.println("Error loading transactions");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
