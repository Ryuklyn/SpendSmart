//package com.example.oop_project.service;
//
//import com.example.oop_project.DBConnection.DBConnection;
//import com.example.oop_project.model.UserDetails;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//public class UserService {
//    public void insertUser(UserDetails user) throws SQLException {
//        String query = "insert into registered_users (username, password) Values(?,?)";
//           PreparedStatement preparedStatement = new DBConnection().getStatement(query);
//           preparedStatement.setString(1, user.getUserName());
//           preparedStatement.setString(2, user.getPassword());
//           preparedStatement.execute();
//    }
//
//    public void editUser(int id, UserDetails user) {
//        String query = "update student set userName = ?, address = ?, password = ?" + " where id = ?";
//        PreparedStatement preparedStatement = new DBConnection().getStatement(query);
//        try {
//            preparedStatement.setString(1, user.getUserName());
//            preparedStatement.setString(2, user.getAddress());
//            preparedStatement.setString(3, user.getPassword());
//            preparedStatement.setInt(4, id);
//            preparedStatement.execute();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void deleteUser(int id) {
//        String query = "delete from student where id=?";
//        PreparedStatement preparedStatement = new DBConnection().getStatement(query);
//        try {
//            preparedStatement.setInt(1, id);
//            preparedStatement.execute();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public UserDetails getUserDetails(String username, String password) {
//        UserDetails user = null;
//        String query = "select * from user_details where userName=? and password=?";
//        PreparedStatement preparedStatement = new DBConnection().getStatement(query);
//        try {
//            preparedStatement.setString(1, username);
//            preparedStatement.setString(2, password);
//
//            ResultSet resultSet = preparedStatement.executeQuery();
//            while ((resultSet.next())) {
//                 user= new UserDetails();
//                user.setId(resultSet.getInt("id"));
//                user.setUserName(resultSet.getString("userName"));
//                user.setPassword(resultSet.getString("password"));
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return user;
//    }
//
//    public List<UserDetails> getUserList() throws SQLException{
//        List<UserDetails> userList = new ArrayList<>();
//        String query = "select * from user_details";
//        PreparedStatement preparedStatement = new DBConnection().getStatement(query);
//        ResultSet resultSet = preparedStatement.executeQuery();
//
//        while (resultSet.next()){
//            UserDetails user = new UserDetails();
//            user.setId(resultSet.getInt("id"));
//            user.setUserName(resultSet.getString("userName"));
//            user.setAddress(resultSet.getString("address"));
//            user.setPassword(resultSet.getString("password"));
//            userList.add(user);
//        }
//        return userList;
//    }
//}
