package com.example.oop_project;

import java.io.IOException;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/UserProfileServlet")
public class UserProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve user profile data from the database
        String userId = request.getParameter("userId");
        String query = "SELECT * FROM userprofile WHERE user_id = ?";
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/expensetracker",
                "root", "admin");
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, Integer.parseInt(userId));
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                // Retrieve data from the result set
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String phone = resultSet.getString("phone");

                // Set attributes to be used in JSP
                request.setAttribute("userId", userId);
                request.setAttribute("name", name);
                request.setAttribute("email", email);
                request.setAttribute("phone", phone);

                // Forward the request to the JSP page
                request.getRequestDispatcher("userProfile.jsp").forward(request, response);
            } else {
                // Handle case where user ID is not found
                response.sendRedirect("error.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception
            response.sendRedirect("error.jsp");
        }
    }

    // Additional methods for handling photo upload, name, email, and phone updates
    // ...

    // Example method for photo upload
    private void uploadPhoto(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userId = request.getParameter("userId");
        Part filePart = request.getPart("fileInput");

        try (InputStream inputStream = filePart.getInputStream();
             Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name",
                     "your_username", "your_password");
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "UPDATE userprofile SET profile_photo = ? WHERE user_id = ?")) {

            preparedStatement.setBlob(1, inputStream);
            preparedStatement.setInt(2, Integer.parseInt(userId));
            preparedStatement.executeUpdate();

            response.sendRedirect("userProfile.jsp?userId=" + userId);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception
            response.sendRedirect("error.jsp");
        }
    }
}
