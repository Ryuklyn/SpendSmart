package com.example.oop_project;

import com.example.oop_project.DBConnection.DBConnection;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.*;
import java.security.NoSuchAlgorithmException;

import com.example.oop_project.passwordhashing.HashPassword;


@WebServlet(name = "LoginServlet", value = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection con = null;

        try {
            con = DBConnection.getConnection();
            String name = request.getParameter("userName");
            String plainPassword = request.getParameter("password");

            if (con != null) {
                String hashedPasswordToCheck = HashPassword.hash(plainPassword);

                PreparedStatement ps = con.prepareStatement("SELECT username FROM registered_users WHERE username=? AND password=?");
                ps.setString(1, name);
                ps.setString(2, hashedPasswordToCheck);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("username", name);
//                    session.setMaxInactiveInterval(60);

                    Cookie userCookie = new Cookie("username", name);
                    userCookie.setMaxAge(60 * 60 * 24 * 7);
                    response.addCookie(userCookie);

                    response.sendRedirect("/pages/dashboard.jsp");
                } else {
                    response.sendRedirect("/pages/login.jsp?error=invalid");
                }
            }
        } catch (SQLException | NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}