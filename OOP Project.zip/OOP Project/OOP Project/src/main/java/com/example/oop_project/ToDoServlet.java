package com.example.oop_project;

import com.example.oop_project.DBConnection.DBConnection;
import com.example.oop_project.model.Task;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import java.util.List;
import java.util.ArrayList;
import javax.servlet.jsp.jstl.core.LoopTagStatus;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ToDoServlet")
public class ToDoServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve task information from the request parameters
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String dueDate = request.getParameter("dueDate");

        try {
            Connection conn = DBConnection.getConnection();
            String query = "INSERT INTO expensetracker.todolist (title, description, duedate) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setString(3, dueDate);


            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error executing SQL query: " + e.getMessage());
            e.printStackTrace();
        }

        // Redirect back to the task list page
        response.sendRedirect(request.getContextPath() + "/pages/todolist.jsp");
    }

//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        try {
//            Connection conn = DBConnection.getConnection();
//            String query = "SELECT title, description, duedate FROM expensetracker.todolist";
//            PreparedStatement stmt = conn.prepareStatement(query);
//            ResultSet resultSet = stmt.executeQuery();
//            System.out.println("get");
//
//            List<Task> tasks = new ArrayList<>();
//
//            while (resultSet.next()) {
//                String title = resultSet.getString("title");
//                String description = resultSet.getString("description");
//                String dueDate = resultSet.getString("duedate");
//
//                Task task = new Task( title, description, dueDate);
//                tasks.add(task);
//            }
//
//            request.setAttribute("tasks", tasks);
//            request.getRequestDispatcher("/pages/todolist.jsp").forward(request, response);
//
//        } catch (SQLException e) {
//            System.err.println("Error executing SQL query: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();
            String query = "SELECT * FROM expensetracker.todolist ORDER BY duedate DESC LIMIT 5";
            PreparedStatement stmt = conn.prepareStatement(query);

            ResultSet rs = stmt.executeQuery();

            List<Task> tasks = new ArrayList<>();

            while (rs.next()) {
                String title = rs.getString("title");
                String description = rs.getString("description");
                String dueDate = rs.getString("duedate");

                Task task = new Task(title, description, dueDate);
                tasks.add(task);
            }

            // Convert tasks to HTML
            tasks.forEach(task -> {
                out.println("<div class='card task-card'>");
                out.println("<div class='card-body'>");
                out.println("<h5 class='card-title'>" + task.getTitle() + "</h5>");
                out.println("<p class='card-text'>Description: " + task.getDescription() + "</p>");
                out.println("<p class='card-text'>Due Date: " + task.getDueDate() + "</p>");
                out.println("</div>");
                out.println("</div>");
            });

        } catch (SQLException e) {
            e.printStackTrace();
            out.println("Error loading tasks");
        }
    }
}
