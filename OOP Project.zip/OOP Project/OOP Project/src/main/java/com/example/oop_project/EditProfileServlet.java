package com.example.oop_project;

import com.example.oop_project.DBConnection.DBConnection;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet("/EditProfileServlet")
public class EditProfileServlet extends HttpServlet {
//    private static final long serialVersionUID = 1L;

//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        try {
//            // Establish database connection
//            Connection connection = DBConnection.getConnection();
//
//            // Prepare SQL statement for fetching user profile data
//            String query = "SELECT fullname, email, phone, birthdate FROM userprofile WHERE user_id = ?";
//            PreparedStatement preparedStatement = connection.prepareStatement(query);
//
//            // Set user_id based on your application logic (session, request parameter, etc.)
//            int userId = 1; // Replace with your actual logic to get user_id
//            preparedStatement.setInt(1, userId);
//
//            // Execute the query
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            if (resultSet.next()) {
//                // Retrieve data from the result set
//                String fullName = resultSet.getString("fullname");
//                String email = resultSet.getString("email");
//                String phone = resultSet.getString("phone");
//                Date birthdate = resultSet.getDate("birthdate");
//
//                // Set the attributes to be used in the JSP page
//                request.setAttribute("fullname", fullName);
//                request.setAttribute("email", email);
//                request.setAttribute("phone", phone);
//                request.setAttribute("birthdate", birthdate);
//            }
//
//            // Close resources
//            resultSet.close();
//            preparedStatement.close();
//            connection.close();
//
//            response.sendRedirect("/pages/userdetails.jsp");
////            dispatcher.forward(request, response);
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            // Redirect to an error page if fetching data fails
//            response.sendRedirect(request.getContextPath() + "/error.jsp");
//        }
//    }

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get user input from the form
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String birthdate = request.getParameter("birthdate");

        try {
            // Establish database connection
            Connection connection = DBConnection.getConnection();

            // Prepare SQL statement for updating user profile
            String query = "UPDATE userprofile SET fullname = ?, email = ?, phone = ?, birthdate = ? WHERE user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, fullName);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phone);

            // Check if birthdate is not null or empty before parsing
            if (birthdate != null && !birthdate.isEmpty()) {
                // Convert birthdate String to java.sql.Date
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                java.util.Date parsedDate = sdf.parse(birthdate);
                java.sql.Date sqlDate = new java.sql.Date(parsedDate.getTime());

                preparedStatement.setDate(4, sqlDate);
            } else {
                // Handle the case where birthdate is null or empty
                preparedStatement.setNull(4, java.sql.Types.DATE);
            }

            // Set user_id based on your application logic (session, request parameter, etc.)
            int userId = 1; // Replace with your actual logic to get user_id
            preparedStatement.setInt(5, userId);

            // Execute the update statement
//            int rowsAffected = preparedStatement.executeUpdate();

            // Close resources
            preparedStatement.close();
            connection.close();

//            if (rowsAffected > 0) {
                // Redirect to the userdetails.jsp page after updating
                response.sendRedirect(request.getContextPath() + "/pages/userdetails.jsp");
//            } else {
//                // Redirect to an error page if no rows were updated
//                response.sendRedirect(request.getContextPath() + "/error.jsp");
//            }

        } catch (SQLException | ParseException e) {
            e.printStackTrace();
            getServletContext().log("Error in EditProfileServlet", e);
            // Redirect to an error page if the update fails
            response.sendRedirect(request.getContextPath() + "/error.jsp");
        }
    }

}
