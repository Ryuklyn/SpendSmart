package com.example.oop_project.model;

import java.util.Date;

public class TodoList {
    private int id;
    private String task;
    private boolean completed;
    private Date dueDate;

    public TodoList(int id, String task, boolean completed, Date dueDate) {
        this.id = id;
        this.task = task;
        this.completed = completed;
        this.dueDate = dueDate;
    }

    public TodoList(){
        //Default Constructor
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
}
