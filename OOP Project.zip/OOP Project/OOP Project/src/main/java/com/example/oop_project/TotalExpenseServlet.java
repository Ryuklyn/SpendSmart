package com.example.oop_project;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
//package com.example.oop_project;

import com.example.oop_project.DBConnection.DBConnection;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/totalExpenseServlet")

//@WebServlet(name = "TotalExpenseServlet", value = "/TotalExpenseServlet")
public class TotalExpenseServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();

            // Get the total expense sum
            String sumQuery = "SELECT SUM(amount) AS totalAmount FROM addtransaction WHERE category = 'Expense'";
            PreparedStatement sumStmt = conn.prepareStatement(sumQuery);
            ResultSet sumRs = sumStmt.executeQuery();

            // Print the total expense sum
            if (sumRs.next()) {
                double totalAmount = sumRs.getDouble("totalAmount");
                out.println("Rs. " + totalAmount);
            } else {
                out.println("No expense data available.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.println("Error fetching total expense");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
