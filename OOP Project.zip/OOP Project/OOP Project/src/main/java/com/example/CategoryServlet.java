package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CategoryServlet")
public class CategoryServlet extends HttpServlet {
    // ... existing code ...

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        // Get the category data from the request parameters
        String newCategory = request.getParameter("newCategory");
        String categoryType = request.getParameter("categoryType");

        // JDBC database connection information
        String url = "jdbc:mysql://localhost:3306/expensetracker";
        String username = "root";
        String password = "admin";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish a database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create SQL query to insert a new category into the table
            String insertCategoryQuery = "";

            if ("expense".equals(categoryType)) {
                insertCategoryQuery = "INSERT INTO category (newexpense) VALUES (?)";
            } else if ("income".equals(categoryType)) {
                insertCategoryQuery = "INSERT INTO category (newincome) VALUES (?)";
            }

            // Prepare the statement
            PreparedStatement categoryStatement = connection.prepareStatement(insertCategoryQuery);

            // Set parameter for the query
            categoryStatement.setString(1, newCategory);

            // Execute the query
            categoryStatement.executeUpdate();

            // Close the prepared statement and the database connection
            categoryStatement.close();
            connection.close();

            // Redirect to categories.jsp after successful category addition
            response.sendRedirect(request.getContextPath() + "/pages/categories.jsp");

        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }

}

