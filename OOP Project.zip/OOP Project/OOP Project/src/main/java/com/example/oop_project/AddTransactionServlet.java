package com.example.oop_project;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet(name = "AddTransactionServlet", value = "/AddTransactionServlet")
//public class AddTransactionServlet extends HttpServlet {

//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html");
//        PrintWriter out = response.getWriter();
//
//        String url = "jdbc:mysql://localhost:3306/expensetracker";
//        String username = "root";
//        String password = "admin";
//
//        try {
//            Connection connection = DriverManager.getConnection(url, username, password);
//
//            String category = request.getParameter("category");
//            String amountParam = request.getParameter("amount");
//            String transactionDateParam = request.getParameter("transaction_date");
//            String transactionTimeParam = request.getParameter("transaction_time");
//            String remarks = request.getParameter("remarks");
//
//
//            if (category != null && amountParam != null && transactionDateParam != null && transactionTimeParam != null) {
//                BigDecimal amount = new BigDecimal(amountParam);
//                Date transactionDate = Date.valueOf(transactionDateParam);
//                Time transactionTime = Time.valueOf(transactionTimeParam);
//
//
//                String insertTransactionQuery = "INSERT INTO transaction (category, amount, transaction_date, transaction_time, remarks) VALUES (?, ?, ?, ?, ?)";
//                try (PreparedStatement insertStatement = connection.prepareStatement(insertTransactionQuery)) {
//                    insertStatement.setString(1, category);
//                    insertStatement.setBigDecimal(2, amount);
//                    insertStatement.setDate(3, transactionDate);
//                    insertStatement.setTime(4, transactionTime);
//                    insertStatement.setString(5, remarks);
//
//
//                    int rowsAffected = insertStatement.executeUpdate();
//
//
//                } catch (SQLException e) {
//
//                    out.println("Error: " + e.getMessage());
//                }
//            } else {
//
//                out.println("Invalid input. Please provide valid data.");
//            }
//
//
//        } catch (SQLException e) {
//
//            out.println("Error: " + e.getMessage());
//        }
//    }

//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        // Retrieve the transaction information from the request parameters
//        String category = request.getParameter("category");
//        String amount = request.getParameter("amount");
//        String date = request.getParameter("date");
//        String time = request.getParameter("time");
//        String note = request.getParameter("note");
//        try {
//            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expensetracker", "root", "admin");
//            PreparedStatement stmt = conn.prepareStatement("INSERT INTO 'addtransaction' (category, amount, transaction_date, transaction_time, notes) VALUES (?, ?, ?, ?, ?)");
//            stmt.setString(1, category);
//            stmt.setString(2, amount);
//            stmt.setString(3, date);
//            stmt.setString(4, time);
//            stmt.setString(5, note);
//            stmt.executeUpdate();
//            conn.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        response.sendRedirect(request.getContextPath() + "/pages/dashboard.jsp");
//    }

//}

import com.example.oop_project.DBConnection.DBConnection;
import com.example.oop_project.model.NotificationHandler;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/addtransactionservlet")
public class AddTransactionServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the transaction information from the request parameters
        String category = request.getParameter("category");
        String amountStr = request.getParameter("amount");
        String dateStr = request.getParameter("date");
        String timeStr = request.getParameter("time");
        String note = request.getParameter("remarks");

        System.out.println(category);

        // Notify clients about the new transaction
        String notification = "New transaction on " + dateStr + " of " + category;
        NotificationHandler.notifyClients(notification);

        try {
            Connection conn = DBConnection.getConnection();
            String query ="INSERT INTO addtransaction (category, amount, transaction_date, transaction_time, notes) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, category);
            stmt.setString(2, amountStr);
            stmt.setString(3, dateStr);
            stmt.setString(4, timeStr);
            stmt.setString(5, note);

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e);
            response.sendRedirect(request.getContextPath() + "/error.jsp");
        }

        // Redirect back to the dashboard
        response.sendRedirect(request.getContextPath() + "/pages/dashboard.jsp");
    }
}
