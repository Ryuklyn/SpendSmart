////package com.example.oop_project.DBConnection;
////
////import java.sql.Connection;
////import java.sql.DriverManager;
////import java.sql.PreparedStatement;
////import java.sql.SQLException;
////
////public class DBConnection {
////    Connection connection = null;
////
////    public DBConnection() {
////        try {
////            Class.forName("com.mysql.cj.jdbc.Driver");
////            String dbUrl = "jdbc:mysql://localhost:4306/expensetracker";
////            String name = "root";
////            String password = "";
////            this.connection = DriverManager.getConnection(dbUrl, name, password);
////            System.out.println("DB Connected");
////        } catch (SQLException e) {
////            throw new RuntimeException(e);
////        } catch (ClassNotFoundException e) {
////            e.printStackTrace();
////        }
////    }
////
////    public static void main(String[] args) {
////        new DBConnection();
////    }
////
////    public static Connection getConnection() {
////        try {
////            Class.forName("com.mysql.cj.jdbc.Driver");
////            return DriverManager.getConnection("jdbc:mysql://localhost:4306/expensetracker","root","");
////
////        }catch (ClassNotFoundException | SQLException e){
////            e.printStackTrace();
////            return null;
////        }
////    }
////
////    public PreparedStatement getStatement(String query) {
////        PreparedStatement preparedStatement = null;
////
////        try {
////            preparedStatement = connection.prepareStatement(query);
////        } catch (SQLException e) {
////            e.printStackTrace();
////        }
////        return preparedStatement;
////    }
////}
//
//package com.example.oop_project.DBConnection;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//public class DBConnection {
//    private Connection connection = null;
//
//    public DBConnection() {
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            String dbUrl = "jdbc:mysql://localhost:3306/expensetracker";
//            String username = "root";
//            String password = "";
//            this.connection = DriverManager.getConnection(dbUrl, username, password);
//            System.out.println("DB Connected");
//        } catch (ClassNotFoundException e) {
//            throw new RuntimeException("MySQL JDBC Driver not found", e);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public static Connection getConnection() {
//        return InstanceHolder.INSTANCE.connection;
//    }
//
//    public PreparedStatement getStatement(String query) {
//        return null;
//    }
//
//
//    private static class InstanceHolder {
//        private static final DBConnection INSTANCE = new DBConnection();
//    }
//
//    public PreparedStatement getPreparedStatement(String query) {
//        try {
//            return connection.prepareStatement(query);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//
//    public void closeConnection() {
//        if (connection != null) {
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
package com.example.oop_project.DBConnection;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    public static Connection getConnection(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/expensetracker","root","admin");
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

